<?php
$servername = "localhost";
$username = "selrom";
$password = "selrom@123";
$dbname = "poslite";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
    // echo "Selrom Connected";
}


?>