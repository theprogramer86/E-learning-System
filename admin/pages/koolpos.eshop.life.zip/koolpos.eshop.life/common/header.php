
<?
$websetting = $conn->query("SELECT * FROM zapp_setting")->fetch_assoc();

?>
<link rel="icon" href="img/k100.png" />
<title><?php echo $websetting['web_name']; ?></title>
