<footer class="sticky-footer bg-white">
                <div class="container text-left my-auto">
                    <div class="copyright my-auto">
                        <span><?php echo $websetting['web_name']; ?></span>
                    </div>
                    
                    
                    
                </div>
                
                <div class="container text-right my-auto">
                    <div class="copyright my-auto">
                    <span><a href="http://www.koolelegance.com.my" target="_blank"> <?php print_r($websetting['copyright_details']); ?></a>,&nbsp All Rights Reserved.</span>
                    </div>
                    
                    
                    
                </div>
            </footer>