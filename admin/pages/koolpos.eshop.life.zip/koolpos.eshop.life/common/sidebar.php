<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <img src="img/logo.png">
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-print"></i>
                    <span>Sales</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="temp-pos.php">Point of Sale</a>
                        <a class="collapse-item" href="billing-report.php">Sales Report</a>
                        <a class="collapse-item" href="billing-user-report.php">User Wise Report</a>
                        <a class="collapse-item" href="billing-desc-report.php">Item Wise Summary</a>
                        <a class="collapse-item" href="billing-user-summary.php">User Wise Summary</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseV"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-vcard"></i>
                    <span>Accounts</span>
                </a>
                <div id="collapseV" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        
                        <a class="collapse-item" href="voucher.php">Voucher Entry</a>
                        <a class="collapse-item" href="voucher_group.php">Account Group Master</a>
                        <a class="collapse-item" href="day_book.php">Day Book Statement</a>
                        <a class="collapse-item" href="income.php">Income & Expense</a>
                        <a class="collapse-item" href="report_expance.php">Expense Report</a>
                        <a class="collapse-item" href="report_income.php">Incomes Report</a>
                        <a class="collapse-item" href="voucher_list.php">Vouchers List</a>
                        
                        
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseV11"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-building-o"></i>
                    <span>Stock</span>
                </a>
                <div id="collapseV11" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        
                        <a class="collapse-item" href="stock-master.php">Stock Entry</a>
                        <a class="collapse-item" href="stock-report.php">Stock Report</a>
                    </div>
                </div>
            </li>
            
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-shopping-basket"></i>
                    <span>Item</span>
                </a>
                <div id="collapseOne" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="item.php">Item Master</a>
                        <a class="collapse-item" href="category.php">Category Master</a>
                        <a class="collapse-item" href="item_list.php">Items List</a>
                        
                    </div>
                </div>
            </li>
            
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#gurukul"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-address-book-o"></i>
                    <span>Gurukkal</span>
                </a>
                <div id="gurukul" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="gurukkal-commision-report.php">Gurukkal Commission Report</a>
                        <!--<a class="collapse-item" href="#">Gurukkal Master</a>-->
                        <a class="collapse-item" href="gurukkal.php">Gurukkal Master</a>
                    </div>
            </li>
            
            
             <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOneVIII"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-group"></i>
                    <span>Users</span>
                </a>
                <div id="collapseOneVIII" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="user.php">Users Management</a>
                   
                </div>
            </li>
            
            
             <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOneIX"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span>
                </a>
                <div id="collapseOneIX" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="setting.php">Settings</a>
                   
                </div>
            </li>
            
            
            

            
            
          

            <!-- Divider -->
            <hr class="sidebar-divider">


            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


        </ul>